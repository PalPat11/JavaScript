import express from "express"
import cors from "cors"
import { createNumFours, doesExist, getAll, getById } from "./db/db.js";
import { NumberFours } from "./db/numberClass.js";

const app = express();

app.use(express.json())

app.use(cors())

const PORT = 3030;

app.post("/fours",async(req,res)=>{
    try{
        const reqObject = req.body;
        if(reqObject.numbers.length>4 || reqObject.numbers.length<4){
            return res.status(400).send("Invalid data")
        }
        const toCreate = new NumberFours(reqObject.numbers[0], reqObject.numbers[1],reqObject.numbers[2], reqObject.numbers[3])
        const exist = await doesExist(toCreate);
        if(exist){
            return res.status(409).send("Already exists")
        }

        const alm = await createNumFours(toCreate)
        res.json(alm)
    }catch(err)
    {
        res.status(500).send("Internal Server Error");
    }
})

app.get("/fours/:id", async (req,res)=>{
    try{
        const {id} = req.params;
        const result = await getById(id);

        let list = [result.aNum, result.bNum, result.cNum, result.dNum]
            const myObject ={
                id: result.id,
                numbers:list
            }
        res.json(myObject)


    }catch(err){
        res.status(500).send("Internal Server Error")
    }
})


app.get("/fours", async (req,res)=>{
    try{
        const nums = await getAll()


        let myList = []
        nums.map((num)=> {
            let list = [num.aNum, num.bNum, num.cNum, num.dNum]
            const myObject ={
                id: num.id,
                numbers:list
            }

            myList.push(myObject)
        })


        res.json(myList);
    }catch(err){
        res.status(500).send("Internam Server Error")
    }
})



app.listen(PORT, ()=>{
    console.log("Listening on port: "+PORT)
})