import Database from "better-sqlite3";

const db = new Database('./db/db.db')

db.prepare(`CREATE TABLE IF NOT EXISTS 'four-numbers'(
    'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    'aNum' INTEGER NOT NULL,
    'bNum' INTEGER NOT NULL,
    'cNum' INTEGER NOT NULL,
    'dNum' INTEGER NOT NULL

)`).run();


export const doesExist = (numberFours)=>{

    const resp = db.prepare(`SELECT * 
FROM 'four-numbers'
WHERE 
    'four-numbers'.aNum=?
AND 'four-numbers'.bNum=?
AND 'four-numbers'.cNum=? 
AND 'four-numbers'.dNum=?;
`).all(numberFours.a, numberFours.b, numberFours.c,numberFours.d)

    if(resp.length==0){
        return false;
    }
    else{
        return true;
    }
}


export const createNumFours = (numberFours) =>{
    return db.prepare(`INSERT INTO 'four-numbers'(
    'aNum', 'bNum', 'cNum', 'dNum'
) VALUES(?, ?, ?, ?)
`).run(numberFours.a, numberFours.b, numberFours.c, numberFours.d)
}

export const getById=(id)=>{
    return db.prepare(`SELECT * 
FROM 'four-numbers'
WHERE 'four-numbers'.id=?;
`).get(id);
}

export const getAll=()=>{
    return db.prepare(`SELECT * 
FROM 'four-numbers';`).all();
}