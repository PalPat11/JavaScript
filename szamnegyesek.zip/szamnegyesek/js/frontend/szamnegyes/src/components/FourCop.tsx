import React from "react";
import type { FoursModel } from "../Pages/Fours";

interface props {
  fours: FoursModel;
}
export const FourCop = ({ fours }: props) => {
  return (
    <div style={{ display: "flex" }}>
      <span>[</span>
      {fours.numbers.map((num) => (
        <div>{num}</div>
      ))}
      <span> ] </span>
    </div>
  );
};
