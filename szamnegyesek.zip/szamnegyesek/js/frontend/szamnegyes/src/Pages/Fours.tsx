import React, { useEffect, useState } from "react";
import { apiClient } from "../../API/apiClient";
import { FourCop } from "../components/FourCop";

const Fours = () => {
  const [fours, setFours] = useState<FoursModel[]>([]);
  useEffect(() => {
    fetchFours();
  }, []);

  const fetchFours = async () => {
    try {
      const resp = await apiClient.get<FoursModel[]>("/fours");

      if (resp.status == 200) {
        console.log("gut");
        setFours(resp.data);
      }
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <div>
      {fours.map((four) => (
        <div>
          Id: {four.id}
          <FourCop fours={four} />
        </div>
      ))}
    </div>
  );
};

export default Fours;
export type FoursModel = {
  id: number;
  numbers: number[];
};
