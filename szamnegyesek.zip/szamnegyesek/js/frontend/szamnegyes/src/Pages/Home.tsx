import { useEffect, useRef, useState } from "react";
import { apiClient } from "../../API/apiClient";
import { Navigate, useNavigate } from "react-router-dom";

import "./Home.css";

function Home() {
  const navigate = useNavigate();
  const [aNum, setANum] = useState<string>("");
  const [bNum, setBNum] = useState<string>("");
  const [cNum, setCNum] = useState<string>("");
  const [dNum, setDNum] = useState<string>("");

  const firstInputRef = useRef<HTMLInputElement>(null);
  const secondInputRef = useRef<HTMLInputElement>(null);
  const thirdInputRef = useRef<HTMLInputElement>(null);
  const fourthInputRef = useRef<HTMLInputElement>(null);

  const maxLength = 1;

  const submitNumbers = async () => {
    try {
      const numbers: number[] = [
        parseInt(aNum),
        parseInt(bNum),
        parseInt(cNum),
        parseInt(dNum),
      ];
      const alm = {
        numbers: numbers,
      };
      const resp = await apiClient.post("/fours", alm);
      if (resp.status == 200) {
        setANum("");
        setBNum("");
        setCNum("");
        setDNum("");

        console.log("GUT");
      } else {
        console.log("Nem jou xd");
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <>
      <div id="alma" style={{ display: "flex", flexDirection: "row" }}>
        <input
          ref={firstInputRef}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={aNum}
          onKeyDown={(e) => {
            if (e.key === "Backspace") {
              setANum("");
            }
          }}
          onChange={(e) => {
            if (aNum.length >= maxLength) {
              return;
            }
            const v = e.target.value;
            if (/^\d*$/.test(v)) {
              setANum(v);
              if (aNum.length >= 0) {
                secondInputRef.current?.focus();
              }
            }
          }}
        />
        <input
          ref={secondInputRef}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={bNum}
          onKeyDown={(e) => {
            if (e.key === "Backspace") {
              setBNum("");
              firstInputRef.current?.focus();
            }
          }}
          onChange={(e) => {
            if (bNum.length >= maxLength) {
              return;
            }
            const v = e.target.value;
            if (/^\d*$/.test(v)) {
              if (bNum != "") {
                setCNum(v);
                fourthInputRef.current?.focus();
              }
              setBNum(v);
              if (bNum.length >= 0) {
                thirdInputRef.current?.focus();
              }
            }
          }}
        />
        <input
          ref={thirdInputRef}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={cNum}
          onKeyDown={(e) => {
            if (e.key === "Backspace") {
              setCNum("");
              secondInputRef.current?.focus();
            }
          }}
          onChange={(e) => {
            if (cNum.length >= maxLength) {
              return;
            }
            const v = e.target.value;
            if (/^\d*$/.test(v)) {
              if (cNum != "") {
                setDNum(v);
                fourthInputRef.current?.focus();
              }
              setCNum(v);
              if (cNum.length >= 0) {
                fourthInputRef.current?.focus();
              }
            }
          }}
        />
        <input
          ref={fourthInputRef}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={dNum}
          onKeyDown={(e) => {
            if (e.key === "Backspace") {
              setDNum("");
              thirdInputRef.current?.focus();
            }
          }}
          onChange={(e) => {
            if (dNum.length >= maxLength) {
              return;
            }
            const v = e.target.value;
            if (/^\d*$/.test(v)) {
              setDNum(v);
            }
          }}
        />
      </div>
      <button onClick={submitNumbers}>Küldés</button>
      <button onClick={() => navigate("/fours")}>Check fours</button>
    </>
  );
}

export default Home;
