import { useEffect, useRef, useState } from "react";
import { apiClient } from "../API/apiClient";

import "./App.css";
import Home from "./Pages/Home";
import { Route, Router, Routes } from "react-router-dom";
import Fours from "./Pages/Fours";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/fours" element={<Fours />} />
      </Routes>
    </>
  );
}

export default App;
