﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace szamnegyes;

public static class Services
{

    public static void ModifyABOard(int value, int[,] matrix)
    {

        for (int x = 0; x < value; x++)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i == 0 || i == 1) && (j == 1 || j == 0))
                    {
                        matrix[i, j]++;
                    }
                }
            }
        }
    }

    public static void ModifyBBOard(int value, int[,] matrix)
    {


        for (int x = 0; x < value; x++)
        {

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i == 0 || i == 1) && (j == 1 || j == 2))
                    {
                        matrix[i, j]++;
                    }
                }
            }
        }


    }

    public static void ModifyCBOard(int value, int[,] matrix)
    {


        for (int x = 0; x < value; x++)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i == 2 || i == 1) && (j == 1 || j == 0))
                    {
                        matrix[i, j]++;
                    }
                }
            }
        }


    }
    public static void ModifyDBOard(int value, int[,] matrix)
    {

        for (int x = 0; x < value; x++)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if ((i == 2 || i == 1) && (j == 1 || j == 2))
                    {
                        matrix[i, j]++;
                    }
                }
            }
        }

    }

    private static void rosszxd()
{
        Console.WriteLine("Hello, World!");

        int[,] board = new int[3, 3];

        Random rng = new Random();

        double rand = rng.NextDouble();

        string randToSrting = rand.ToString();


        string alma = randToSrting.Replace("0", "");
        string ban = alma.Replace(",", "");

        int a = int.Parse(ban[0].ToString());
        int b = int.Parse(ban[1].ToString());
        int c = int.Parse(ban[2].ToString());
        int d = int.Parse(ban[3].ToString());

        int[] correctAnswer = new int[4];

        for (var i = 0; i < 4; i++)
        {
            correctAnswer[i] = int.Parse(ban[i].ToString());
        }

        int[,] doneBoard = CreateBoard(board);

        PrintMatrix(doneBoard);














        void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"[{matrix[i, j]}]");
                }
                Console.WriteLine();
            }

        }



        int[,] CreateBoard(int[,] matrix)
        {
            ModifyABOard(a, matrix);
            ModifyBBOard(b, matrix);
            ModifyCBOard(c, matrix);
            ModifyDBOard(d, matrix);

            return matrix;
        }





    }
    // See https://aka.ms/new-console-template for more information
 

}
