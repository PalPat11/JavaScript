﻿List<int> listFromUsers = GetUserInput();

int[,] board = CreateBoard(listFromUsers);

PrintMatrix(board);

ResultOfValidaion isValid = ValidateBoard(board);

if (isValid.Result == false)
{
    Console.WriteLine("[-1]");
}
else
{
    Console.Write("[");

    foreach (var item in isValid.numbers)
    {
        Console.Write($"{item}, ");
    }

    Console.Write("]");
}




    ResultOfValidaion ValidateBoard(int[,] board)
    {
        int a = ModifyABOard(board);
        int b = ModifyBBOard(board);
        int c = ModifyCBOard(board);
        int d = ModifyDBOard(board);

        List<int> list = new List<int>()
    {
        a, b, c, d
    };

        int[] correctAnswer = list.ToArray();


        bool booleanREsult = true;

        for (int i = 0; i < board.GetLength(0); i++)
        {
            for (int j = 0; j < board.GetLength(1); j++)
            {
                if (board[i, j] != 0)
                {
                    booleanREsult = false;
                }



            }
        }
        var alm = new ResultOfValidaion
        {
            Result = booleanREsult,
            numbers = correctAnswer
        };
        return alm;
    }



void PrintMatrix(int[,] matrix)
{
    for (int i = 0; i < matrix.GetLength(0); i++)
    {
        for (int j = 0; j < matrix.GetLength(1); j++)
        {
            Console.Write($"[{matrix[i, j]}]");
        }
        Console.WriteLine();
    }

}


int[,] CreateBoard(List<int> listFromUsers)
{
    int[,] alma= new int[3,3];
    int listIndex = 0;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            alma[i, j] = listFromUsers[listIndex];
            listIndex++;
        }
    }

    return alma;
}





List<int> GetUserInput()
{
    List<int> list = new List<int>();

    for(int i = 0; i < 9; i++)
    {
        int number = GetInput();
        list.Add(number);
    }

    return list;
}


int GetInput()
{
    bool result = false;
    int number = 0;

    while (!result)
    {
        Console.WriteLine("Adja meg a számot");
        string input = Console.ReadLine();


        result = int.TryParse(input, out number);


    }

    return number;
}

int ModifyABOard(int[,] matrix)
{
    int value = matrix[0,0];
    for (int x = 0; x < value; x++)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if ((i == 0 || i == 1) && (j == 1 || j == 0))
                {
                    matrix[i, j]--;
                }
            }
        }
    }

    return value;
}

int ModifyBBOard(int[,] matrix)
{

    int value = matrix[0, 2];

    for (int x = 0; x < value; x++)
    {

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if ((i == 0 || i == 1) && (j == 1 || j == 2))
                {
                    matrix[i, j]--;
                }
            }
        }
    }
    return value;

}

int ModifyCBOard(int[,] matrix)
{

    int value = matrix[2, 0];

    for (int x = 0; x < value; x++)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if ((i == 2 || i == 1) && (j == 1 || j == 0))
                {
                    matrix[i, j]--;
                }
            }
        }
    }

    return value;
}
int ModifyDBOard(int[,] matrix)
{
    int value = matrix[2, 2];

    for (int x = 0; x < value; x++)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if ((i == 2 || i == 1) && (j == 1 || j == 2))
                {
                    matrix[i, j]--;
                }
            }
        }
    }

    return value;

}

class ResultOfValidaion
{
    public bool Result { get; set; }
    public int[] numbers { get; set; } = new int[3];

}

