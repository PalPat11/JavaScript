﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using szamnegyes;

namespace szamnegyesek_desktop;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{

    public MainWindow()
    {
        InitializeComponent();
    }

    private int[,] board = new int[3, 3];

    private void Button_Click_A(object sender, RoutedEventArgs e)
    {
        Services.ModifyABOard(1, board);
        RenderBoard();
    }

    private void Button_Click_B(object sender, RoutedEventArgs e)
    {
        Services.ModifyBBOard(1, board);
        RenderBoard();

    }

    private void Button_Click_C(object sender, RoutedEventArgs e)
    {
        Services.ModifyCBOard(1, board);
        RenderBoard();

    }

    private void Button_Click_D(object sender, RoutedEventArgs e)
    {
        Services.ModifyDBOard(1, board);
        RenderBoard();


    }

    private void RenderBoard()
    {
        Cell00.Content = board[0, 0];
        Cell01.Content = board[0, 1];
        Cell02.Content = board[0, 2];

        Cell10.Content = board[1, 0];
        Cell11.Content = board[1, 1];
        Cell12.Content = board[1, 2];

        Cell20.Content = board[2, 0];
        Cell21.Content = board[2, 1];
        Cell22.Content = board[2, 2];
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        Cell00.Content = 0;
        Cell01.Content = 0;
        Cell02.Content = 0;

        Cell10.Content = 0;
        Cell11.Content = 0;
        Cell12.Content = 0;

        Cell20.Content = 0;
        Cell21.Content = 0;
        Cell22.Content = 0;
    }
}